/*
 *
 * Bethany A. Kuczin
 * 13 December 2020
 * CS 210
 * Project 3
 *
 */

#include <iostream>  // for cin cout
#include <fstream>   // for file management
#include <sstream>   // for file management
#include <iomanip>   // for setting the width and justify
#include <iterator>  // for file management
#include <vector>    // for vector management
#include <string>    // for string management
#include <jni.h>     // for java code interaction
using namespace std;

////////////////////////////////////////////////////////////////////////////////////

class Animal {  //base class

   public:
      string name;
      int TrackNum;


     Animal(){
        name = "catdog";
        TrackNum = 900900;

     } // Default constructor


// setters
     void setName (string nameVar){
         name = nameVar;
      }
      void setTrackNum (int trackNumVar){
         TrackNum = trackNumVar;
      }

// getters
     string getName (){
          return name;
      }
      int getTrackNum (){
          return TrackNum;
      }

}; // end class Animal

/////////////////////////////////////////////////////////////////////////////////////
class Oviparous: public Animal  // extends Animal derived class
{
   public:
      int NumberOfEggs;

      Oviparous(){
         NumberOfEggs = 0;
         } // Default constructor

// setters
   void setNumberOfEggs (int numberEggsVar){
       NumberOfEggs = numberEggsVar;
   }

//getters
    int getNumberOfEggs (){
        return NumberOfEggs;
    }

};  // end class Oviparous
 ///////////////////////////////////////////////////////////////////////////////////
class Mammal: public Animal // extends Animal derived class
{
   public:
      int Nurse;

      Mammal(){
         Nurse = 0;
          } // Default constructor

// setters
   void setNurse (int nurseVar){
       Nurse = nurseVar;
   }

//getters
    int getNurse (){
        return Nurse;
    }

};
///////////////////////////////////////////////////////////////////////////////////////
class Crocodile: public Oviparous // extends Animal and Oviparous derived class
{

   public:
      Crocodile(){
         } // Default constructor

};
////////////////////////////////////////////////////////////////////////////////////////
class Goose: public Oviparous  // extends Animal and Oviparous derived class
{

   public:
      Goose(){
         } // Default constructor

};
///////////////////////////////////////////////////////////////////////////////////////
class Pelican: public Oviparous  // extends Animal and Oviparous derived class
{

   public:
      Pelican(){
         } // Default constructor

};
///////////////////////////////////////////////////////////////////////////////////////
class Bat: public Mammal  // extends Animal and Mammal derived class
{

   public:
      Bat(){
         } // Default constructor

};
//////////////////////////////////////////////////////////////////////////////////////
class Whale: public Mammal  // extends Animal and Mammal derived class
{

   public:
      Whale (){
         } // Default constructor
};
//////////////////////////////////////////////////////////////////////////////////////
class SeaLion: public Mammal  // extends Animal and Mammal derived class
{

   public:
      SeaLion(){
         } // Default constructor
};







//renamed function GenerateData() to createZooFile()
void createZooFile()  //GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
           JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
           JNIEnv *env;                      // Pointer to native interface
                                                                    //================== prepare loading of Java VM ============================
           JavaVMInitArgs vm_args;                        // Initialization arguments
           JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
           options[0].optionString = (char*) "-Djava.class.path=";   // where to find java .class
           vm_args.version = JNI_VERSION_1_6;             // minimum Java version
           vm_args.nOptions = 1;                          // number of options
           vm_args.options = options;
           vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                                //=============== load and initialize Java VM and JNI interface =============
           jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
           delete options;    // we then no longer need the initialisation options.
           if (rc != JNI_OK) {
                  // TO DO: error processing...
                  cin.get();
                  exit(EXIT_FAILURE);
           }
           //=============== Display JVM version =======================================
           cout << "JVM load succeeded: Version ";
           jint ver = env->GetVersion();
           cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

           jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
           if (cls2 == nullptr) {
                  cerr << "ERROR: class not found !";
           }
           else {                                  // if class found, continue
                  cout << "Class MyTest found" << endl;
                  jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
                  if (mid == nullptr)
                         cerr << "ERROR: method void createZooFile() not found !" << endl;
                  else {
                         env->CallStaticVoidMethod(cls2, mid);                      // call method
                         cout << endl;
                  }
           }


           jvm->DestroyJavaVM();
           cin.get();
}


void AddAnimal(vector<string>*vecMain)
{
     /*
            Code to add an animal to vecMain vector
     */

	   		   string trackingNumber;
	   		   string nameValue;
	   		   string mammalValue;
	   		   string subtypeValue;
	   		   string eggsValue;
	   		   string nurseValue;

	   		   cout << "Enter tracking number: " << endl;
	   		   cin >> trackingNumber;

	   		   cout << "Enter name: " << endl;
	   		   cin >> nameValue;

	   		   cout << "Enter mammal or oviparous: " << endl;
	   		   cin >> mammalValue;

	   		   cout << "Enter sub type: " << endl;
	   		   cin >> subtypeValue;
	   		   cout << subtypeValue << endl;

	   		   cout << "Enter number of eggs: " << endl;
	   		   cin >> eggsValue;

	   		   cout << "Enter 1 if nursing otherwise enter 0: " << endl;
	   		   cin >> nurseValue;

               cout << "You have chosen to add the following record: " << endl;
               cout << "|Track#|" << setw(15) << left << "Name" << "|" << setw(15) << left << "Type"
            		<< "|" << setw(15) << left << "Sub-type" << "|" << setw(11) << left << "Eggs"
            		<< "|" << setw(11) << left << "Nurse" << "|" << endl;
               cout.fill('_');
               cout << setw(80) << "" << endl;
               cout.fill(' ');
               cout << "|" << setw(6) << left << trackingNumber << "|" << setw(15) << left << nameValue
            		<< "|" << setw(15) << left << mammalValue << "|" << setw(15) << left << subtypeValue
            		<< "|" << setw(11) << left << eggsValue << "|" << setw(11) << left  << nurseValue << "|" << endl;
               cout.fill('_');
               cout << setw(80) << "" << endl;
               cout.fill(' ');
               char addVal = '?';
               cout << endl << "Enter y to ADD and any other key to not add: " << endl;
               cin >> addVal;
               if (addVal == 'y'){

	   		      vecMain->push_back(trackingNumber);
	   		      vecMain->push_back(nameValue);
	   		      vecMain->push_back(mammalValue);
	   		      vecMain->push_back(subtypeValue);
	   		      vecMain->push_back(eggsValue);
	   		      vecMain->push_back(nurseValue);

	   		      cout << "Animal Record Added." << endl;
               }
               else{
            	  cout << "Animal Record Not Added." << endl;
               }

}

void RemoveAnimal(vector<string>*vecMain)
{
     /*
            Code to remove an animal from vecMain
     */


	string trackingNumber;

	cout << "Enter the tracking number of the animal you wish to delete: " << endl;
	cin >> trackingNumber;

	for (unsigned int i = 0; i < vecMain->size(); ++i){

		if (trackingNumber == vecMain->at(i)){
			cout << "You have chosen to delete the following record: " << endl;
			cout << "|Track#|" << setw(15) << left << "Name" << "|" << setw(15) << left << "Type"
					<< "|" << setw(15) << left << "Sub-type" << "|" << setw(11) << left << "Eggs"
					<< "|" << setw(11) << left << "Nurse" << "|" << endl;
			cout.fill('_');
			cout << setw(80) << "" << endl;
			cout.fill(' ');
			cout << "|" << setw(6) << left << vecMain->at(i) << "|" << setw(15) << left << vecMain->at(i+1)
			     << "|" << setw(15) << left << vecMain->at(i+2) << "|" << setw(15) << left << vecMain->at(i+3)
				 << "|" << setw(11) << left << vecMain->at(i+4) << "|" << setw(11) << left  << vecMain->at(i+5)  << "|" << endl;
			cout.fill('_');
			cout << setw(80) << "" << endl;
			cout.fill(' ');
			char deleteVal = '?';
			cout << endl << "Enter y to DELETE and any other key to not delete: " << endl;
			cin >> deleteVal;
			if (deleteVal == 'y'){
				vecMain->erase(vecMain->begin()+i, vecMain->begin()+(i+6));
				cout << "Animal Successfully Deleted." << endl;
			}
			else{
				cout << "Returning to Main Menu..." << endl;
			}
		}else {
			continue;
		}
	}



}

void LoadDataFromFile(int menuChoice, vector<string>*vecMain)
{
     /*
           Code to load data from input file (generated using JNI) into vector vecMain.
     */

if (menuChoice == 1) {
	string recordnameChars;
	string nurseChar;
	string eggsChar;
	string mammalChars;
	string typeChars;

	ifstream infile("zoodata.txt"); //open file
	if (!infile){
		cerr << "File not available: " << "zoodata.txt" << std::endl;
		//exit function
	}
	else{

	   while (!infile.eof()){
	      infile >> recordnameChars >> mammalChars >> typeChars >> eggsChar >> nurseChar;

	      string recordVal = recordnameChars.substr(0,6);
	      string nameVal = recordnameChars.substr(6,21);

	      vecMain->push_back(recordVal);
	      vecMain->push_back(nameVal);
	      vecMain->push_back(mammalChars);
	      vecMain->push_back(typeChars);
	      vecMain->push_back(eggsChar);
	      vecMain->push_back(nurseChar);
	   }
	}

	   cout << "Data File Loaded" << endl;



}
}

void SaveDataToFile(vector<string>* vecMain)
{
     /*
            Code to store vecMain vector to myZooFile.txt file.
     */

	fstream myZooFile;

	myZooFile.open("myZooFile.txt", std::ofstream::out | std::ofstream::trunc); //Create file, open it, and empty it

	   // If no file is created, then
	   // show the error message.
	   if(!myZooFile)
	   {
	       cout<<"Error in creating file!!!" << endl;
	   }
	   else{
	   cout<<"File created successfully." << endl;
	   }

	   cout << "Loading data to file..." << endl;  // Load data to file
	   ofstream output_file("./myZooFile.txt");
	   ostream_iterator<string> output_iterator(output_file, "\n");
	   copy(vecMain->begin(), vecMain->end(), output_iterator);

	   myZooFile.close(); // Close file

	   cout << "Save Successfully Completed" << endl;

}

void DisplayRecords(vector<string>* vecMain){

	cout.fill('_');
	cout << setw(80) << "" << endl;
	cout.fill(' ');

   cout << "|Track#|" << setw(15) << left << "Name" << "|" << setw(15) << left << "Type"
		<< "|" << setw(15) << left << "Sub-type" << "|" << setw(11) << left << "Eggs"
		<< "|" << setw(11) << left << "Nurse" << "|" << endl;

   cout.fill('_');
   cout << setw(80) << "" << endl;
   cout.fill(' ');
   for (unsigned int i = 0; i < vecMain->size();++i){

	  cout << "|" << setw(6) << left << vecMain->at(i) << "|" << setw(15) << left << vecMain->at(i+1)
	       << "|" << setw(15) << left << vecMain->at(i+2) << "|" << setw(15) << left << vecMain->at(i+3)
	   	   << "|" << setw(11) << left << vecMain->at(i+4) << "|" << setw(11) << left << vecMain->at(i+5)  << "|" << endl;

	  cout.fill('_');
	  cout << setw(80) << "" << endl;
	  cout.fill(' ');
      i=i+5;
   } // end for loop
}


void DisplayMenu()
{
     /*
            Code to display menu to user and get user menu selection
     */

	 char caseChar = '?';
	 vector<string> vecMain;


	 while (caseChar != 'x'){
	   cout << "**********************************************************" << endl;
	   cout << "1: Load Animal Data"  << endl;  // load data file into a vector vecMain
	   cout << "2: Generate Data" << endl;   //access java code
	   cout << "3: Display Animal Data" << endl;
	   cout << "4: Add Record" << endl;  // record added to vector vecMain
	   cout << "5: Delete Record" << endl; // record deleted from vector vecMain
	   cout << "6: Save Animal Data" << endl;   // vector changes saved to a file
	   cout << "x: to eXit application" << endl;  // added to allow for application termination
	   cout << "**********************************************************" << endl;
       cin >> caseChar;

	   switch (caseChar){

	      case '1': LoadDataFromFile(1, &vecMain);
	                break;
	      case '2': createZooFile();  //GenerateData();
	                break;
	      case '3': DisplayRecords(&vecMain);
	                break;
	      case '4': AddAnimal(&vecMain);
	                break;
	      case '5': RemoveAnimal(&vecMain);
	                break;
	      case '6': SaveDataToFile(&vecMain);
	                break;
	      case 'x': break;
	      case 'X': caseChar = 'x';
	                break;
	      default:  cout << "Invalid entry.  Please enter 1, 2, 3, 4, 5, 6, x, or X" << endl;
	   }  // end switch

	} // end while

    cout << "x or X Entered. Application Terminated" << endl;

}



int main()
{
    DisplayMenu();
    cout << "END OF MAIN" << endl;
	return 1;

}
